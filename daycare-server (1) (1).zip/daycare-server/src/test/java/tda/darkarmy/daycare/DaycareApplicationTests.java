package tda.darkarmy.daycare;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DaycareApplicationTests {

	@Test
	void contextLoads() {
	}

}
